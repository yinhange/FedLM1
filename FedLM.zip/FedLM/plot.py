import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import numpy as np
import random
import glob
import pandas as pd
import os

# 设置中文字体
from matplotlib.font_manager import FontProperties
font_path = r"D:\FedFTG-main\ziti\FangZhengShuSongJianTi-1.ttf"
font = FontProperties(fname=font_path, size=14)

# 全局设置字体
matplotlib.rcParams['font.family'] = font.get_name()
matplotlib.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 查找系统中的中文字体
cur_alg = 'only-atte'
e_mode = 'e1'
names = glob.glob('./plot/{}mul-{}/alg_*'.format(cur_alg, e_mode))

names_box = glob.glob('./plot/best_acc_{}/best_acc_*.npy'.format(e_mode))
names_cut = [name.split('/')[3] for name in names_box]

alg_name = [name.split('.')[0].split('best_acc_')[1] for name in names_cut]
print(alg_name)

# specify the directory path
directory_path ="E:\\fedlm\FedLM\cifar100_resnet18_0.6"
# directory_path ="E:\\fedlm\FedLM\cifar100_resnet18_0.3"
# directory_path ="E:\\fedlm\FedLM\cifar100_resnet18_0.1"


# directory_path = "E:\\fedlm\FedLM\cifar100_lenet5_0.6"
# directory_path ="E:\\fedlm\FedLM\cifar100_lenet5_0.3"
# directory_path = "E:\\fedlm\FedLM\cifar100_lenet5_0.1"

# directory_path = "E:\\fedlm\FedLM\cifar10_lenet5_0.6"
# directory_path = "E:\\fedlm\FedLM\cifar10_lenet5_0.3"
# directory_path ="E:\\fedlm\FedLM\cifar10_lenet5_0.1"

fedm_icfl = []

for filename in os.listdir(directory_path):
    if os.path.isfile(os.path.join(directory_path, filename)):
        fedm_icfl.append(os.path.join(directory_path, filename))

index = 'y'
fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)
legend = []
leng_npy = len(fedm_icfl)

if index == 'y':
    op = [
        'ax.plot(x,y,marker=\'x\',color=\'green\',markersize=5,markevery=5)',
        'ax.plot(x,y,marker=\'D\',color=\'purple\',markersize=5,markevery=5)',
        'ax.plot(x,y,marker = \'d\',markersize=5,color=\'brown\', markevery=5)',
        'ax.plot(x,y,marker=\'>\', color=\'magenta\',markersize=5,markevery=5)',
        'ax.plot(x,y,marker=\'*\',markersize=5,color=\'orange\',markevery=5)',
        'ax.plot(x,y,marker=\'>\',color=\'pink\',markersize=5,markevery=5)',
        'ax.plot(x,y,marker = \'+\',markersize=5,color=\'yellow\', markevery=5)',
        'ax.plot(x,y,marker = \'o\',markersize=5,color=\'red\', markevery=5)',
        'ax.plot(x,y,marker= \'^\',markersize=5,color=\'blue\', markevery=5)',
        'ax.plot(x,y,marker = \'^\',markersize=5,color=\'black\', markevery=5)',
        'ax.plot(x,k,marker = \'+\',markersize=5,color=\'gray\', markevery=5)',
    ]

best_acc = []
for idx, stri in enumerate(fedm_icfl):
    x, y, z, k = np.load(stri, allow_pickle=True)
    step = 5

    if 'resnet' in directory_path or 'lenet5' in directory_path:
        k = k[0:101]
        z = z[0:101]
        y = y[0:101]
        y = np.append(y, y[98])
        x = list(range(0, 1010, 10))
        s = pd.Series(y)
        y = s.rolling(window=5, min_periods=1).mean()
        y = y[0:101]

    best_acc.append(max(y))
    eval(op[idx])
    legend.append(stri.split('alg_')[1].split('-')[0])

# fig.suptitle('通信轮次的测试准确率', fontsize=18, fontweight='bold', fontproperties=font)

ax.set_xlabel("通信轮次/轮", fontsize=18, fontproperties=font)
ax.set_ylabel("测试准确率", fontsize=18, fontproperties=font)

if 'cifar100_lenet5' in directory_path:
    plt.ylim(20, 56)
if 'cifar10_lenet5' in directory_path:
    plt.ylim(50, 85)
if 'cifar100_resnet18' in directory_path:
    plt.ylim(10, 66)
if 'cifar10_resnet18' in directory_path:
    plt.ylim(50, 95)

x_max = max(x)
plt.xlim(0, x_max)
plt.tight_layout()
legend1 = tuple(legend)

plt.xticks(fontsize=16, fontproperties=font)
plt.yticks(fontsize=16, fontproperties=font)
plt.legend((legend1), fontsize=14, prop=font)

plt.show()
random_name = str(float(random.random()))[0:8]
plt.savefig('./plot/' + random_name + '.png')

print('ok!')

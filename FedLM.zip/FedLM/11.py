import numpy as np
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# 查找系统中的中文字体，并设置字体大小
zh_font = fm.FontProperties(fname='D:\FedFTG-main\ziti\FangZhengShuSongJianTi-1.ttf', size=16)  # 修改为你的系统路径，并设置字体大小

def generate_dirichlet_data(alpha, num_clients=10, num_classes=10):
    np.random.seed(0)
    data_distribution = np.random.dirichlet([alpha] * num_classes, num_clients)
    return data_distribution

# 生成数据
alpha_values = [0.1, 0.3, 0.6]
data_0_1 = generate_dirichlet_data(0.1)
data_0_3 = generate_dirichlet_data(0.3)
data_0_6 = generate_dirichlet_data(0.6)

# 绘制气泡图
fig, axs = plt.subplots(1, 3, figsize=(18, 6))

for ax, data, alpha, label in zip(axs, [data_0_1, data_0_3, data_0_6], alpha_values, ['(a)', '(b)', '(c)']):
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            ax.scatter(i + 1, j + 1, s=data[i, j] * 500, alpha=0.5)  # 缩小气泡大小
    ax.set_xlabel(f'设备编号\n{label} Dirichlet α={alpha}', fontproperties=zh_font)
    ax.set_ylabel('类别编号', fontproperties=zh_font)
    ax.set_title(f'{label} Dirichlet α={alpha}', fontproperties=zh_font)
    ax.grid(True)
    ax.set_xticks(np.arange(1, 11, 1))
    ax.set_yticks(np.arange(1, 11, 1))

plt.suptitle('CIFAR-10数据集在不同异构设置下前10个客户端的数据分布图', fontproperties=zh_font)
plt.subplots_adjust(top=0.85)
plt.show()

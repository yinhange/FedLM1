import ray
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from model import ConvNet, ConvNet_EMNIST 
from utils import *
from copy import deepcopy
from math import exp
import math
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# device = torch.device('cpu')

@ray.remote
class ParameterServer(object):
    def __init__(self, lr, alg, tau, data_name, num_workers):
        if data_name =='CIFAR10':
            self.model = ConvNet()
        else:
            self.model = ConvNet_EMNIST()   
        self.optimizer = torch.optim.SGD(self.model.parameters(), lr=lr)
        self.momen_v = None
        self.num_workers = num_workers
        self.gamma =0.9
        self.beta = 0.99
        self.alg = alg 
        self.lr_ps = lr

        self.ps_c = None
        self.c_all = None
        #上一代的c
        self.c_all_pre = None
        
        self.tau = tau
        self.cnt = 0
        self.alpha = None

    def get_state(self):
        return self.ps_c, self.c_all
    def set_state(self,c_dict):
        self.ps_c = c_dict[0]
        self.c_all = c_dict[1]  
    def set_weights(self, weights):
        self.model.set_weights(weights)  
    def attention(self, c_cur, c_pre):
        '''
        手动softmax
        Q: 当前机子，当前轮的信息
        K: 当前机子，上一轮的信息
        '''
        produces = []
        for cur, pre in zip(c_cur, c_pre):
            #对于每个机子
            total_produce = 0
            for k, v in cur.items():
                #对于该机子的每一层
                Q = F.normalize(v.view(1, -1))
                K = F.normalize(pre[k].view(1, -1))
                layer_produce = exp(Q.mm(K.t()).item())
                total_produce += layer_produce 
            produces.append(total_produce)
        sum_all = sum(produces)
        alpha = [p/sum_all for p in produces]
        # print('~~~~~',alpha)
        return alpha

    def attention_api(self, c_cur, c_pre):
        '''
        api softmax
        Q: 当前机子，当前轮的信息
        K: 当前机子，上一轮的信息
        '''
        produces = []
        for cur, pre in zip(c_cur, c_pre):
            #对于每个机子
            total_produce = 0
            for k, v in cur.items():
                #对于该机子的每一层
                Q = F.normalize(v.view(1, -1))
                K = F.normalize(pre[k].view(1, -1))
                layer_produce = Q.mm(K.t()).item()
                total_produce += layer_produce 
            produces.append(total_produce)
        alpha = torch.tensor(produces)
        alpha = F.softmax(alpha,dim=0).tolist()
        # print('~~~~~',alpha)
        return alpha

    def attention_global(self, c_cur):
        '''
        手动softmax
        Q: 全局的（平均的），当前轮的信息
        K: 当前机子，当前轮的信息
        '''
        produces = []
        #获取全局平均信息
        global_c = self.ps_c
        for cur in c_cur:
            #对于每个机子
            total_produce = 0
            for k, v in cur.items():
                #对于该机子的每一层
                Q = F.normalize(v.view(1, -1))
                K = F.normalize(global_c[k].view(1, -1))
                layer_produce = exp(Q.mm(K.t()).item())
                total_produce += layer_produce 
            produces.append(total_produce)
        sum_all = sum(produces)
        alpha = [p/sum_all for p in produces]
        # print('~~~~~',alpha)
        return alpha

    def set_pre_c(self, c):
        self.c_all_pre = c

    def apply_weights_avg(self, num_workers, *weights):
        sum_weights = {}
        for weight in weights:
            for k,v in weight.items():
                if k in sum_weights.keys():
                    sum_weights[k]+=v / num_workers
                else:
                    sum_weights[k]=v / num_workers
        self.model.set_weights(sum_weights)
        return self.model.get_weights()
    
    def apply_weights_moment(self, num_workers, *weights):
        sum_weights = {}
        for weight in weights:
            for k,v in weight.items():
                if k in sum_weights.keys():
                    sum_weights[k]+=v / num_workers
                else:
                    sum_weights[k]=v / num_workers
        weight_ps = self.model.get_weights()
        for k,v in weight_ps.items():
            sum_weights[k]-=v
        if not self.momen_v:
            self.momen_v = deepcopy(sum_weights)
        else:
            for k,v in self.momen_v.items():
                self.momen_v[k]=self.gamma * v + sum_weights[k]
        seted_weight ={}
        for k,v in weight_ps.items():
            seted_weight[k]=v+self.momen_v[k]
        self.model.set_weights(seted_weight)
        return self.model.get_weights()

    def apply_weights_adam_atte(self, num_workers, *weights):
        '''
        拓展联邦attention到adam
        '''
        if not self.c_all:
            alpha = [1/num_workers] * num_workers
        else:
            alpha = self.attention_global(self.c_all)
        delta_t = {}
        for weight, cur_alpha in zip(weights, alpha):
            for k,v in weight.items():
                if k in delta_t.keys():
                    delta_t[k]+= v * cur_alpha
                else:
                    delta_t[k]= v * cur_alpha

        weight_ps = self.model.get_weights()
        for k,v in weight_ps.items():
            delta_t[k]-=v
        if not self.momen_v:
            self.momen_v = deepcopy(delta_t)
            for k,v in delta_t.items():
                #adam
                self.momen_v[k] =self.beta * 0.1 + (1-self.beta) * v.mul(v)
        else:
            for k,v in self.momen_v.items():
                #v = beta * v +(1-beta)*delta_t^2
                # if k=='fc1.weight':
                    # print('v[0]',v[0])
                self.momen_v[k]=self.beta * v + (1-self.beta) * delta_t[k].mul(delta_t[k])

        seted_weight ={}
        for k,v in weight_ps.items():
            # if k=='fc1.weight':
                # print('delat', delta_t[k] / (self.momen_v[k].sqrt()+ self.tau))
            seted_weight[k]=v +  self.lr_ps * delta_t[k] / (self.momen_v[k].sqrt()+ self.tau)
        self.model.set_weights(seted_weight)
        return self.model.get_weights()
    def apply_weights_adam(self, num_workers, *weights):
        delta_t = {}
        mode = 'Adam' #Adagrad
        for weight in weights:
            for k,v in weight.items():
                if k in delta_t.keys():
                    delta_t[k]+=v / num_workers
                else:
                    delta_t[k]=v / num_workers
        weight_ps = self.model.get_weights()
        for k,v in weight_ps.items():
            delta_t[k]-=v
        if not self.momen_v:
            self.momen_v = deepcopy(delta_t)
            for k,v in delta_t.items():
                #adam
                if mode=='Adam':
                    self.momen_v[k] =self.beta * 0.1 + (1-self.beta) * v.mul(v)
                #adagrad
                if mode=='Adagrad':
                    self.momen_v[k] = 0.1 + v.mul(v) 
        else:
            for k,v in self.momen_v.items():
                #v = beta * v +(1-beta)*delta_t^2
                # if k=='fc1.weight':
                    # print('v[0]',v[0])
                #adam
                if mode=='Adam':
                    self.momen_v[k]=self.beta * v + (1-self.beta) * delta_t[k].mul(delta_t[k])
                #adagrad
                if mode=='Adagrad':
                    self.momen_v[k]=v +  delta_t[k].mul(delta_t[k])


        seted_weight ={}
        for k,v in weight_ps.items():
            # if k=='fc1.weight':
                # print('delat', delta_t[k] / (self.momen_v[k].sqrt()+ self.tau))
            seted_weight[k]=v +  self.lr_ps * delta_t[k] / (self.momen_v[k].sqrt()+ self.tau)

        self.model.set_weights(seted_weight)
        return self.model.get_weights()

    def apply_weights_atte(self, num_workers, *weights):
        '''
        对于所有的ds发来的weights, 我还需要再保存上一代的信息weights'
        '''
        if not self.c_all_pre:
            alpha = [1/num_workers] * num_workers
        else:
            alpha = self.attention(self.c_all, self.c_all_pre)
        sum_weights = {}
        for weight, cur_alpha in zip(weights, alpha):
            for k,v in weight.items():
                if k in sum_weights.keys():
                    sum_weights[k]+= v * cur_alpha
                else:
                    sum_weights[k]= v * cur_alpha
        self.model.set_weights(sum_weights)
        return self.model.get_weights()

    def apply_weights_global_atte(self, num_workers, *weights):
        '''
        对于所有的ds发来的weights, 我还需要再保存上一代的信息weights'
        '''
        if not self.c_all:
            alpha = [1/num_workers] * num_workers
        else:
            alpha = self.attention_global(self.c_all)
        sum_weights = {}
        for weight, cur_alpha in zip(weights, alpha):
            for k,v in weight.items():
                if k in sum_weights.keys():
                    sum_weights[k]+= v * cur_alpha
                else:
                    sum_weights[k]= v * cur_alpha
        self.model.set_weights(sum_weights)
        return self.model.get_weights()

    def produce(self, cur, pres):
        '''
        作用：   对于机子j，输出它由所有机子的状态生成自己的表示的权重
        输入    cur: 当前要处理的某一个机子
                pres: 上一代所有机子的更新量(cur所依赖的信息)
        '''
        e_list = []
        for pre in pres:
            sum_e = 0
            for k,v in cur.items():
                cur_i, pre_i = v.view(1, -1), pre[k].view(1, -1)
                cur_i, pre_i =  F.normalize(cur_i), F.normalize(pre_i)
                e = exp(cur_i.mm(pre_i.t()).item())
                sum_e += e 
            e_list.append(sum_e) 
        sum_all = sum(e_list)
        prod = [e/sum_all for e in e_list]
        return prod

    def attention_compex(self):
        '''

        输入     c_cur:所有机子发来的更新量
                c_pre:上一代所有机子的更新量
        输出    每个机子的表示组成的列表
        '''
        c_cur = self.c_all
        c_pre = self.c_all_pre
        attention_list = [self.produce(cur, c_pre) for cur in c_cur]
        # print('(attention_list):',attention_list[0])
        return attention_list

    def sf_attention(self):
        c_cur = self.c_all
        if not self.c_all:
            return torch.eye(self.num_workers).tolist()
        attention = [self.produce(cur, c_cur) for cur in c_cur]
        # print('(attention-1):',attention[-1])
        # print('(attention-2):',attention[-2])
        # print('(attention0):',attention[0])
        return attention
    def apply_weights_mutilayer(self, num_workers, *weights):
        '''
        双层的注意力
        '''
        if not self.c_all_pre:
            alpha = torch.eye(num_workers).tolist()
        else:
            alpha = self.attention_compex()

        sum_weights_list = []
        for cur_alpha in alpha:
            sum_weights = {}
            for weight, cur_alpha_j in zip(weights, cur_alpha):
                for k,v in weight.items():
                    if k in sum_weights.keys():
                        sum_weights[k]+= v * cur_alpha_j
                    else:
                        sum_weights[k]= v * cur_alpha_j
            sum_weights_list.append(sum_weights)
        new_weights = {}
        for weight in sum_weights_list:
            for k,v in weight.items():
                if k in new_weights.keys():
                    new_weights[k]+= v / num_workers
                else:
                    new_weights[k]= v / num_workers
        self.model.set_weights(new_weights)
        return self.model.get_weights()

    def apply_weights_selfatte(self, num_workers, *weights):
        alpha = self.sf_attention()
        self.cnt +=1
        if self.cnt %2==0:
            if self.alpha ==None:
                self.alpha =[]
            elif alpha[0]!=np.nan:
                self.alpha.append(alpha)
            
        sum_weights_list = []
        for cur_alpha in alpha:
            sum_weights = {}
            for weight, cur_alpha_j in zip(weights, cur_alpha):
                for k,v in weight.items():
                    if k in sum_weights.keys():
                        sum_weights[k]+= v * cur_alpha_j
                    else:
                        sum_weights[k]= v * cur_alpha_j
            sum_weights_list.append(sum_weights)
        new_weights = {}
        for weight in sum_weights_list:
            for k,v in weight.items():
                if k in new_weights.keys():
                    new_weights[k]+= v / num_workers
                else:
                    new_weights[k]= v / num_workers
        self.model.set_weights(new_weights)
        return self.model.get_weights()
    def load_dict(self):
        self.func_dict = {
            'FedAvg': self.apply_weights_avg,
            'FedAvgM': self.apply_weights_moment,
            'cddplus': self.apply_weights_avg,
            'cdd': self.apply_weights_avg,
            'SCAF': self.apply_weights_avg,
            'atte': self.apply_weights_atte,
            'GLFL': self.apply_weights_avg,
            'mutilayer-atte': self.apply_weights_mutilayer,
            'self-atte': self.apply_weights_selfatte,
            'global-atte': self.apply_weights_global_atte,
            'FedAdam': self.apply_weights_adam,
            'only-atte': self.apply_weights_atte,
            'only-atte-self': self.apply_weights_selfatte,
            # 'only-atte': self.apply_weights_global_atte,
            'adam_atte': self.apply_weights_adam_atte,
            'collection':self.apply_weights_avg,
            'IGFL-BG': self.apply_weights_global_atte,
            'momentum-step': self.apply_weights_avg
        }
    def apply_weights_func(self, alg, num_workers, *weights):
        self.load_dict()
        return self.func_dict.get(alg, None)(num_workers, *weights)

    def apply_ci(self, alg, num_workers, *cis):
        '''
        平均所有的ds发来的sned_ci, delta_cis
        '''
        if 'atte' in alg:
            # 先将当前状态传给self.c_all_pre, 再平均所有的ds发来的ci，更新self.ps_c
            self.set_pre_c(self.c_all)
            self.c_all = cis
        sum_c = {}
        for ci in cis:
            for k,v in ci.items():
                if k in sum_c.keys():
                    sum_c[k] += v / num_workers
                else:
                    sum_c[k] = v / num_workers
        if self.ps_c==None:
            self.ps_c = sum_c
            return self.ps_c
        for k,v in self.ps_c.items():
            #c = c + 1/P * \sum tilda_ci
            self.ps_c[k] = v + sum_c[k]
        return self.ps_c

    def apply_ci_atte(self, num_workers, *cis):
        '''
        先将当前状态传给self.c_all_pre, 再平均所有的ds发来的ci，更新self.ps_c
        '''
        self.set_pre_c(self.c_all)
        sum_c = {}
        self.c_all = cis
        for ci in cis:
            for k,v in ci.items():
                if k in sum_c.keys():
                    sum_c[k] += v / num_workers
                else:
                    sum_c[k] = v / num_workers
        if self.ps_c==None:
            self.ps_c = sum_c
            return self.ps_c
        for k,v in self.ps_c.items():
            #c = c + 1/P * \sum tilda_ci
            self.ps_c[k] = v + sum_c[k]
        return self.ps_c

    def get_weights(self):
        return self.model.get_weights()
    def get_ps_c(self):
        return self.ps_c
    def get_attention(self):
        return self.alpha

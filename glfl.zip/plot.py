# import matplotlib as mplmpl.use('Agg')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import random
import glob
import pandas as pd
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

cur_alg = 'only-atte'
e_mode = 'e1'
names = glob.glob('./plot/{}mul-{}/alg_*'.format(cur_alg, e_mode))

names_box = glob.glob('./plot/best_acc_{}/best_acc_*.npy'.format(e_mode))
names_cut = [name.split('/')[3] for name in names_box]

alg_name = [name.split('.')[0].split('best_acc_')[1] for name in names_cut]
print(alg_name)
import os

# specify the directory path
directory_path = "D:/Users/14577/Desktop/plot/cifar10_lenet5"
#directory_path = "D:/Users/14577/Desktop/plot/cifar10_vgg11"
#directory_path = "D:/Users/14577/Desktop/plot/cifar10_resnet18"
#directory_path = "D:/Users/14577/Desktop/plot/cifar10_vgg19"

directory_path = "D:/Users/14577/Desktop/plot/cifar100_lenet5"
#directory_path = "D:/Users/14577/Desktop/plot/cifar100_vgg11"
#directory_path = "D:/Users/14577/Desktop/plot/cifar100_resnet18"
#directory_path = "D:/Users/14577/Desktop/plot/cifar100_vgg19"

#directory_path = "C:/Users/14577/Desktop/plot/resnet18-0.1/CIFAR10"
#directory_path = "C:/Users/14577/Desktop/plot/resnet18-0.1/CIFAR100"


#directory_path = "C:/Users/14577/Desktop/plot/gamma"
#directory_path = "C:/Users/14577/Desktop/plot/vit_imagenet"
#directory_path = "C:/Users/14577/Desktop/plot/vit_cifar100"



#directory_path = "C:/Users/14577/Desktop/plot/nonconvex"
directory_path = "D:/Users/14577/Desktop/wake/FedSWA_plot/cifar10_lenet5"
#D:\Users\14577\Desktop\wake\FedSWA_plot\cifar10_lenet5

#directory_path = "C:/Users/14577/Desktop/plot/resnet18-1/CIFAR10"
#directory_path = "C:/Users/14577/Desktop/plot/resnet18-1/CIFAR100"
#directory_path = "C:/Users/14577/Desktop/plot/gamma"
#directory_path = "C:/Users/14577/Desktop/plot/Fedbcd/cifar100"

#directory_path = "C:/Users/14577/Desktop/plot/Fedbcd/cifar10"
#directory_path = "C:/Users/14577/Desktop/plot/xiang/lipis_places2"
#

#C:\Users\14577\Desktop\新建文件夹\lipis
#C:/Users/14577/Desktop/plot/xiang/lipis_places2
fedm_icfl = []




for filename in os.listdir(directory_path):
    # check if the file is a file (not a directory)
    if os.path.isfile(os.path.join(directory_path, filename)):
        # do something with the file
        fedm_icfl.append(os.path.join(directory_path, filename))

if 'nonconvex' in directory_path or 'MINIST_2000' in directory_path or 'resnet18' not in directory_path:
    index='z'
else:
    index = 'y'

index = 'y'
fig = plt.figure()
ax = fig.add_subplot(1,1,1)
legend = []
leng_npy = len(fedm_icfl)
if index=='k':
    op = [
        'ax.plot(x,k,marker=\'x\',color=\'green\',markersize=5,markevery=5)',
        'ax.plot(x,k,marker=\'D\',color=\'purple\',markersize=5,markevery=5)',
        'ax.plot(x,k,marker=\'*\',markersize=5,color=\'orange\',markevery=5)',
        'ax.plot(x,k,marker = \'d\',markersize=5,color=\'brown\', markevery=5)',
        'ax.plot(x,y,marker = \'+\',markersize=5,color=\'gray\', markevery=5)',
        #'ax.plot(x,y,marker = \'^\',markersize=5,color=\'black\', markevery=5)',
        'ax.plot(x,k,marker = \'o\',markersize=5,color=\'red\', markevery=5)',
        'ax.plot(x,k,marker= \'^\',markersize=5,color=\'blue\', markevery=5)',

        'ax.plot(x,k,marker=\'>\',color=\'pink\',markersize=5,markevery=5)',
        'ax.plot(x,k,marker=\'>\', color=\'magenta\',markersize=5,markevery=5)',
    ]
if index=='z':
    op = [
        'ax.plot(x,z,marker=\'x\',color=\'green\',markersize=5,markevery=5)',
        'ax.plot(x,z,marker=\'D\',color=\'purple\',markersize=5,markevery=5)',
        'ax.plot(x,z,marker=\'*\',markersize=5,color=\'orange\',markevery=5)',
        'ax.plot(x,z,marker = \'d\',markersize=5,color=\'brown\', markevery=5)',
        'ax.plot(x,z,marker = \'+\',markersize=5,color=\'gray\', markevery=5)',
        #'ax.plot(x,y,marker = \'^\',markersize=5,color=\'black\', markevery=5)',
        'ax.plot(x,z,marker = \'o\',markersize=5,color=\'red\', markevery=5)',
        'ax.plot(x,z,marker= \'^\',markersize=5,color=\'blue\', markevery=5)',

        'ax.plot(x,z,marker=\'>\',color=\'pink\',markersize=5,markevery=5)',
        'ax.plot(x,z,marker=\'>\', color=\'magenta\',markersize=5,markevery=5)',
    ]
if index=='y':

    op = [
        'ax.plot(x,y,marker=\'x\',color=\'green\',markersize=5,markevery=5)',
        'ax.plot(x,y,marker=\'D\',color=\'purple\',markersize=5,markevery=5)',
        'ax.plot(x,y,marker=\'*\',markersize=5,color=\'orange\',markevery=5)',
        'ax.plot(x,y,marker = \'d\',markersize=5,color=\'brown\', markevery=5)',
        #'ax.plot(x,y,marker = \'+\',markersize=5,color=\'gray\', markevery=5)',
        #'ax.plot(x,y,marker = \'^\',markersize=5,color=\'black\', markevery=5)',
        'ax.plot(x,y,marker = \'o\',markersize=5,color=\'red\', markevery=5)',
        'ax.plot(x,y,marker= \'^\',markersize=5,color=\'blue\', markevery=5)',

        'ax.plot(x,y,marker=\'>\',color=\'pink\',markersize=5,markevery=5)',
        'ax.plot(x,y,marker=\'>\', color=\'magenta\',markersize=5,markevery=5)',
    ]

if index=='x':

    op = [
        #'ax.plot(x,y,linestyle=\'-.\',color=\'green\')',
        'ax.plot(x,y,marker=\'o\',color=\'green\',markersize=5,markevery=5)',
        #'ax.plot(x,y,linestyle=\':\',color=\'purple\')',
        'ax.plot(x,y,marker=\'D\',color=\'purple\',markersize=5,markevery=5)',
        'ax.plot(x,y,marker=\'*\',markersize=5,color=\'orange\',markevery=5)',
        'ax.plot(x,y,marker = \'d\',markersize=5,color=\'brown\', markevery=5)',
        #'ax.plot(x,y,marker = \'+\',markersize=5,color=\'gray\', markevery=5)',
        #'ax.plot(x,y,marker = \'^\',markersize=5,color=\'black\', markevery=5)',
        'ax.plot(x,y,marker = \'x\',markersize=5,color=\'red\', markevery=5)',
        'ax.plot(x,y,marker= \'o\',markersize=5,color=\'blue\', markevery=5)',
        #'ax.plot(x,y,linestyle= \'--\',color=\'pink\')',
        'ax.plot(x,y,marker=\'>\',color=\'pink\',markersize=5,markevery=5)',
        'ax.plot(x,y,marker=\'>\', color=\'magenta\',markersize=5,markevery=5)',
    ]




best_acc = []
#STR=[]
for idx,stri in enumerate(fedm_icfl):
    x,y,z,k = np.load(stri, allow_pickle=True)
    step = 5


    if 'cifar' in directory_path and 'vit' not in directory_path or 'resnet' in directory_path or 'lamda' in stri:



        k=k[0:101]
        z=z[0:101]
        y = y[0:101]
        x = list(range(0, 1010, 10))


        s = pd.Series(y)
        #y[0]=1
        y= s.rolling(window=10, min_periods=1).mean()



        y=np.append(y,(y[98]+y[99])/2)
        y = y[0:101]
        #y=np.append(y,(y[78]+y[79])/2)
        #y = y[0:80]


    if 'vit' in directory_path:

        if 'FedBCGD' in stri:
            x=x/6

        new_x = np.linspace(x[0], 100, 120)
        new_y = np.interp(new_x, x, y)
        x=new_x
        y=new_y
        #s = pd.Series(y)
        #y= s.rolling(window=5, min_periods=1).mean()

    if 'nonconvex' in directory_path or 'MINIST_2000' in directory_path:

        k=k[0:41]
        z=z[0:41]
        z = z[0:41]

        x = list(range(0, 410, 10))
        y = y[0:41]



    #
    # if idx==1:
    # x = [E*i for i in x]
    print('---the alg, {} ---'.format(stri))
    #print('best acc:{} in {} epoch, best loss:{}, time cost:{}\n'.format(max(y), step*np.argmax(y) ,min(z[:-1]),z[-1]/max(x)) )
    best_acc.append(max(y))
    eval(op[idx])
    legend.append(stri.split('alg_')[1].split('-')[0])

    # legend.append(stri.split('.npy')[0].split('./plot/')[1].split('/')[1]+str(idx))
fig.suptitle('Test Accuracy with Communication Rounds', fontsize = 18, fontweight='bold')
#fig.suptitle('Test Accuracy with Communication floats', fontsize = 18, fontweight='bold')
#ax.set_xlabel("Epoch")
#ax.set_ylabel("Accuracy")
ax.set_xlabel(" Communication Rounds",fontsize=18)
ax.set_ylabel("Test Accuracy",fontsize=18)
if 'nonconvex' in directory_path or 'MINIST_2000' in directory_path:
    fig.suptitle('Train loss with Communication Rounds', fontsize = 18, fontweight='bold')
    ax.set_ylabel("Train loss", fontsize = 18)
    #fig.suptitle('Test loss with communication floats', fontsize = 18, fontweight='bold')
    #ax.set_ylabel("Test loss", fontsize = 18)

#plt.ylim(0, 4)
#plt.ylim(0, 5)
#plt.ylim(0, 0.3)
if 'cifar100_lenet5' in directory_path:
    plt.ylim(10, 56)
if 'cifar10_lenet5' in directory_path:
    plt.ylim(60, 85)
if 'cifar100_vgg11' in directory_path:
    plt.ylim(10, 65)
if 'cifar10_vgg11' in directory_path:
    plt.ylim(50, 90)
if 'cifar100_vgg19' in directory_path:
    plt.ylim(10, 65)
if 'cifar10_vgg19' in directory_path:
    plt.ylim(50, 90)
if 'cifar100_resnet18' in directory_path:
    plt.ylim(10, 70)
if 'cifar10_resnet18' in directory_path:
    plt.ylim(50, 95)

if 'vit_imagenet' in directory_path:
    plt.ylim(20, 85)
if 'vit_cifar100' in directory_path:
    plt.ylim(60, 95)
if 'resnet18-0.1/CIFAR10' in directory_path:
    plt.ylim(20, 90)
if 'resnet18-0.1/CIFAR100' in directory_path:
    plt.ylim(10, 65)
if 'nonconvex' in directory_path:
    plt.ylim(1.05, 2)
    plt.ylim(0, 0.3)
if 'strongly' in directory_path:
    plt.ylim(1.05, 2)
    #plt.ylim(0, 0.3)
#plt.ylim(1.17, 1.8)


#plt.box(False)

x_max = max(x)
plt.xlim(0, x_max)
plt.tight_layout()
legend1 = tuple(legend)

plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.legend((legend1),fontsize=14)

#plt.legend((legend1))
plt.show()
random_name = str(float(random.random()))[0:8]
print(random_name)
# np.save('./plot/best_acc/best_acc_{}'.format(cur_alg),np.array(best_acc))
plt.savefig('./plot/'+random_name+'.png')




print('ok!')

